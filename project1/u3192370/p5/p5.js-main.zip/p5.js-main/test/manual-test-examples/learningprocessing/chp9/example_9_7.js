// Learning Processing
// Daniel Shiffman
// http://www.learningprocessing.com

// Ported by Lauren McCarthy

// Example 9-7: An array operation using dot length

var values = [];
values.length = 100;

for (var i = 0; i < values.length; i++) {
  values[i] = 0;
}
