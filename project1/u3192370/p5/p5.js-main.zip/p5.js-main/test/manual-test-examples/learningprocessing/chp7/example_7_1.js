// Learning Processing
// Daniel Shiffman
// http://www.learningprocessing.com

// Ported by Lauren McCarthy

// Example 7-1: Defining a function
var drawBlackCircle = function() {
  fill(0);
  ellipse(50, 50, 20, 20);
};
