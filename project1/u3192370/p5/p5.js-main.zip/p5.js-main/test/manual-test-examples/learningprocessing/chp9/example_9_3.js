// Learning Processing
// Daniel Shiffman
// http://www.learningprocessing.com

// Ported by Lauren McCarthy

// Example 9-3: Initializing the elements of an array all at once

var arrayOfInts = [1, 5, 8, 9, 4, 5];
var floatArray = [1.2, 3.5, 2.0, 3.4123, 9.9];
