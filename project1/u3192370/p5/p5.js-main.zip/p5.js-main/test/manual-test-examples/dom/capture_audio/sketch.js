var capture;

function setup() {
  createCanvas(390, 240);
  capture = createCapture(AUDIO);
}

function draw() {
  background(255);
}
